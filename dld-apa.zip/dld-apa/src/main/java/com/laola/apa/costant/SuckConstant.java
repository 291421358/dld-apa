package com.laola.apa.costant;

import java.util.HashMap;
import java.util.Map;

public class SuckConstant {
    public static final Map<String,String> SuckMap = new HashMap<String, String>(){
        {
            put("SUCK_REGENT","");
            put("SUCK_SAMPLE","");
        }
    };
}