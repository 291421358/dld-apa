package com.laola.apa.server.impl;

import com.laola.apa.entity.RegentPlace;
import com.laola.apa.mapper.RegentPlaceMapper;
import com.laola.apa.mapper.SelectDao;
import com.laola.apa.server.ReagentPlaceIntf;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

@Service
public class ReagentPlaceImpl implements ReagentPlaceIntf {
    @Autowired
    SelectDao selectDao;
    @Autowired
    RegentPlaceMapper regentPlaceMapper;
    Logger logger = Logger.getGlobal();
    @Override
    public List<Map<String, Object>> getRegentPlace() {
        List<Map<String, Object>> maps = selectDao.selectList("select rp.*,pp.name from regent_place rp\n" +
                "left join project_param pp on rp.project_param_id = pp.id\n" +
                "where rp.project_param_id is not null\n" +
                "Order by id");
        return maps;
    }

    @Override
    public int updateRegentPlace(RegentPlace regentPlace) {
//        RegentPlace regentPlace1 = regentPlaceMapper.selectByPrimaryKey(regentPlace);
//        if (regentPlace1.getProjectParamId() == regentPlace.getProjectParamId())
        Integer count = null;
        if (regentPlace.getProjectParamId() != 0){
            count =100;
        }

        regentPlace.setCount(count);

        int i = regentPlaceMapper.updateByPrimaryKey(regentPlace);
        return i;
    }

    @Override
    public int minusOneCopyReagent(int projectId) {
        logger.info("试剂数量减一 in RP:projectId");
        regentPlaceMapper.minusOneCopyReagentR1(projectId);
        regentPlaceMapper.minusOneCopyReagentR2(projectId);
        return 1;
    }

    @Override
    public Integer getCopies(int projectId) {
        Integer copies = regentPlaceMapper.getCopies(projectId);
        if (copies == null){
            copies = 0;
        }
        return copies;
    }

    @Override
    public boolean getParamIds(int[] paramIds) {
        List paramIdList = regentPlaceMapper.getParamIds();
        String x = paramIdList.toString();
        for (int i:paramIds) {
            if (0!=i && !x.contains(String.valueOf(i))){
                return true;
            }
        }
        return false;
    }
}
