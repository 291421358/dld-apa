var urlhead = 'http://localhost:8081';
var Oid;
var quaslength = 0;

/**
 * 获得某个项目的所有QC项目
 */
function getOneProjectsAllQcByProjectParamId(id) {
    Oid = id;
    $.ajax({
        type: 'get',
        url: urlhead + '/qc/getOneProjectsAllQcByProjectParamId',
        async: true,
        data: {
            projectParamId: id,
        },
        jsonp: 'jsoncallback',
        success: function (data) {
            var projectList = data.projects;
            var canvas = document.getElementById('qcCurve');

            if (canvas.getContext) {
                var ctx = canvas.getContext('2d');
                ctx.clearRect(0, 0, 2000, 2000);
                $.each(projectList,function (i, project) {
                    var ctx3 = canvas.getContext('2d');
                    ctx3.strokeStyle = "blue";
                    ctx3.lineWidth = 0.99;
                    ctx3.strokeText((project.density )+"("+(project.endtime ).toString().substring(5,11).toString()+")", (i - 1) * 30 + 30, 200 - project.density - (i % 6 * 2 - 2) * 5);
                    ctx3.strokeText(project.id  , (i - 1) * 30+30, 210);
                });
                var ctx4 = canvas.getContext('2d');
                ctx4.strokeStyle = "black";
                ctx4.lineWidth = 0.99;
                ctx4.strokeText("0", 3, 200-180);
                ctx4.strokeText("50", 3, 200-50);
                ctx4.strokeText("100", 3, 200-100);
                ctx4.strokeText("150", 3, 200-150);
                ctx4.stroke();
                var ctx5 = canvas.getContext('2d');
                ctx5.strokeStyle = "black";
                ctx5.lineWidth = 0.99;
                ctx5.beginPath();
                ctx5.lineTo(0, 100);
                ctx5.lineTo(canvas.width, 100);
                ctx5.stroke();
                var ctx1 = canvas.getContext('2d');
                ctx1.lineWidth = 2;
                ctx1.strokeStyle = "red";
                ctx1.beginPath();
                $.each(projectList, function (i, project) {
                    ctx1.lineTo((i - 1) * 30 + 25, 200 - project.density);

                });
                ctx1.stroke();

            }
        },
        error: function () {
            $('#message').html("请联系管理员");
        }
    });
}

function updateDensity() {
    console.log("111111");
    $.ajax({
        type: 'post',
        url: urlhead+'/qc/updateDensity',
        async: true,
        data: {
            id: $("#projectId").val(),
            density: $("#density").val(),
        },
        jsonp: 'jsoncallback',
        success: function (data) {
            alert("第"+$("#projectId").val()+"个项目修改为"+$("#density").val());
            getOneProjectsAllQcByProjectParamId(Oid);
        },
        error: function () {
            $('#details').html("有问题");
        }
    });
}
/**
 * 初始化方法；加载项目列表
 */
function irload() {
    $.ajax({
        type: 'get',
        url: urlhead + '/parameter/projectList',
        async: true,
        jsonp: 'jsoncallback',
        success: function (data) {
            var projectList = data;
            var tabStr = "<label class='layui-form-label' style='text-align: left'>项目名</label>";
            $.each(projectList, function (i, project) {
                tabStr += "<div class='layui-form-item'>";
                tabStr += "<input class='layui-btn layui-btn-primary' type='button' paramid=" + project.id + " value=" + project.name + " >";
                tabStr += "</div>";
            });
            $('#projectName').html(tabStr);
            layui.use(['form', 'table'], function () {
                var table = layui.table;
                //监听单元格编辑
                table.on('edit(table1)', function (obj) {
                    var value = obj.value //得到修改后的值
                        , data = obj.data //得到所在行所有键值
                        , field = obj.field; //得到字段
                    layer.msg('[ID: ' + data.id + '] ' + field + ' 字段更改为：' + value);
                });
            });
        },
        error: function () {
            $('#projectName').html("请联系管理员");
        }
    });
}
