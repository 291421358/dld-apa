$(document).ready(function () {
    $("#menu li").click(function (data) {
        var i = data.currentTarget.value;
        jumpPage(i);
    });

    $("#quitBtn").on("click",function () {
        window.location.href="about:blank";
        window.close();
    });
    $("#closeBtn").on("click",function () {
        $("#quit").fadeOut("fast");
        $("#mask").css({display: 'none'});
    });
});

function time() {//
    var date = new Date();
    $("#time").html("<li style='font-family: 隶书;float: left'>&nbsp&nbsp" + date.getFullYear() + "年" + (new Date().getMonth() + 1) + "月" + new Date().getDate() + "日&nbsp" + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds() + "</li>");
    setTimeout(function () {
        time();
    }, 500);
}

var url = "";

function jumpPage(i) {
    console.log(i);
    switch (i) {
        case 1:
            url = "/pages/patients/scaling.html";
            break;
        case 2:
            url = "/pages/patients/input&result.html";
            break;
        case 3:
            url = "/pages/param/projectparam.html";
            break;
        case 4:
            url = "/pages/search/sampleResult.html";
            break;

        case 5:
            url = "/pages/equipment/adjust&AD&parts.html";
            break;
        case 6:
            url = "/pages/laser/laserSpectrum.html";
            break;
        case 7:
            suspend();
            return;

        default:
    }
    console.log(url+"?ranparam="+Math.random());
    $("#content").html("<iframe scrolling='no' src=" + url + " height=650 width=1260 frameborder=null></iframe>")
}
$("#deleteProjectBox").fadeOut("fast");
$("#mask").css({display: 'none'});


var urlhead = getPort();
function suspend() {
    $("#quit").fadeIn("slow");
}


function fullScreen(el) {
    var rfs = el.requestFullScreen || el.webkitRequestFullScreen || el.mozRequestFullScreen || el.msRequestFullScreen,
        wscript;
    rfs.call(el);
    wscript = new ActiveXObject("WScript.Shell");
    if (wscript) {
        wscript.SendKeys("{F11}");
    }
}


function getTem() {
    getEquipmentState();
    setTimeout(getTem,10000);
}
function init() {
    $.ajax({
        type: 'GET',
        url: urlhead + '/adjusted/connect',
        async: true,
        jsonp: 'jsoncallback',
        success: function (event) {
        },
        error: function () {
            alert("error");
        }
    });
}
/**
 * 获取仪器状态数据
 */
function getEquipmentState(){
    $.ajax({
        type: 'get',
        url: urlhead + '/equipmentState/selectOne?id=1',
        async: true,
        jsonp: 'jsoncallback',
        success: function (data) {
            $("#tem").html("<img src=\"images/temp.png\">"+data.reactTemp+"°C");
        },
        error: function () {
            alert("请联系管理员");
        }
    })
}


this.start = new Date().getTime()
let code = ''
let lastTime, nextTime
let lastCode, nextCode
let that = this
document.onkeypress = function (e) {
     console.log("111")
}