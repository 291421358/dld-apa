package com.laola.apa.vo;

public class ProjectTestVO {

    private String x;
    private String y;
}
