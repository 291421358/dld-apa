package com.laola.apa.costant;

public class BaseCostant {
    public static final String head = "E5 90 8C ";
    public static final String ADhead = "E5 90 83 ";
    public static final String LightHead = "E5 90 8E ";
    public static final String SpinHead = "E5 90 91 ";
    public static final String TestHead = "E5 90 7D ";
    public static final String RWHead = "E5 90 9A ";
    public static final String CleanReact = "E5 90 86 ";
    public static final String last = "00 00 00 00 00 00 00 00 00 00";
    /**
     *
     * [2020-01-18 10:38:36.137]# RECV HEX>读取
     * 00 00 00 00 00 00 00 00 00 00
     *
     *
     * [2020-01-18 10:38:41.309]# RECV HEX>写入
     * 88 64 64 00 00 00 00 00 00 00 00 00 00
     *
     * [2020-01-18 10:38:48.888]# RECV HEX>回零
     * E5 90 91 0B 00 01 2C 00 00 00 00 00 00 00 00 00
     *
     * [2020-01-18 10:38:50.421]# RECV HEX>回零
     * E5 90 91 0C 00 00 00 00 00 00 00 00 00 00 00 00
     *
     * [2020-01-18 10:38:51.209]# RECV HEX>洗样品
     * E5 90 91 0C 01 01 2C 00 00 00 00 00 00 00 00 00
     *
     * E5 90 91 0B 01 01 2C 00 00 00 00 00 00 00 00 00
     *
     * [2020-01-18 10:39:06.408]# RECV HEX清洗反应杯。
     * E5 90 86 01 01 07 06 00 00 00 00 00 00 00 00 00
     *
     */
}
