package com.laola.apa.costant;

import java.util.HashMap;
import java.util.Map;

public class CleanReactConstant {
    public static final Map<String,String> CRMap = new HashMap<String, String>(){
        {
            put("CLEANREACT","");
        }
    };
}
