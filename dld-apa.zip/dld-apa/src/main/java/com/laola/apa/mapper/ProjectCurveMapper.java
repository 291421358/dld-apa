package com.laola.apa.mapper;

import com.laola.apa.entity.ProjectCurve;
import com.laola.apa.utils.MyMapper;
import org.springframework.stereotype.Service;

@Service
public interface ProjectCurveMapper extends MyMapper<ProjectCurve> {
}