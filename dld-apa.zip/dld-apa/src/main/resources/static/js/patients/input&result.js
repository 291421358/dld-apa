var urlhead = getPort();
var quasi = 0;
var quaslength = 0;
var projectNameList = [];
var code = 0;
var rackNo = 0;
var key = 0;
var timeout;
var scrollLength = 0;
var savetime = 0;

//根据时间获得项目列表
function getProjectListByDate() {
    // console.log("获取当天所有项目");
    $.ajax({
        type: 'get',
        url: urlhead + '/productTest/getProjectListByData',
        async: true,
        data: {
            endtime: new Date().getFullYear() + "-" + (new Date().getMonth() + 1) + "-" + new Date().getDate()
        },
        jsonp: 'jsoncallback',
        success: function (event) {

            if (quasi >= 1) {
                quasi++;
                //列表长度
                var size = $("#tab tr").length;
                $("#tab tr").slice(2, size - 30).remove();
                dealProject(event);
            } else {
                irLoad(event);
            }
        },
        error: function () {
            alert("error")
        }
    });

};


function getProjectListByDataTenToEnd() {
    // console.log("获取当天所有项目");
    $.ajax({
        type: 'get',
        url: urlhead + '/productTest/getProjectListByDataTenToEnd',
        async: true,
        data: {
            endtime: new Date().getFullYear() + "-" + (new Date().getMonth() + 1) + "-" + new Date().getDate()
        },
        jsonp: 'jsoncallback',
        success: function (event) {

            irLoad(event);
        },
        error: function () {
            alert("error")
        }
    });

};

function dealProject(event) {


    var tr;
    var jsonArr = JSON.parse(event);
    var l = 1;
    var leng = 1;
    //创建一个查找表  函数
    var maxCode = jsonArr['maxCode'];
    let markCanBeDelete = 0;//标记是否可以删除
    var turn = 0;
    for (var i = jsonArr['minCode']; i <= maxCode; i++) {
        var jsonArrElement = jsonArr[i];
        if (null == jsonArrElement) {
            continue;
        }
        tr = "<tr>" +
            "<td>" + i + "</td>" +
            "<td>" + ("null" === jsonArrElement[0].barCode ? "" : jsonArrElement[0].barCode) + "</td>";
        for (let j = 0; j < 9; j++) {
            tr += "<td";
            //循环9次
            for (let k = 0; k < jsonArrElement.length; k++) {
                turn++;
                //循环jsonArrElement
                var progress = "";
                var fac;
                //取当前jsonArrElement[k].projectParamId;
                var paramId = jsonArrElement[k].projectParamId;
                // console.log(projectNameList[j + 2],paramId);
                if (projectNameList[j + 2] === paramId && paramId != "") {
                    //如果项目id相等
                    progress = jsonArrElement[k].progress;
                    if (progress.indexOf("%") >= 0) {
                        // 带有百分号为正在做的项目，为深蓝色
                        tr += " style='background:#007DDB;' ";
                    } else {
                        //已经出结果的项目白色
                        var abnormal = jsonArrElement[k].abnormal;
                        // console.log(abnormal);
                        var title = "";
                        if (abnormal != null && abnormal != "null") {

                            if (abnormal == 1) {
                                tr += " style='background:rgb(254, 154, 154);' ";
                                title += "无试剂次数  ";
                            }
                            else if (abnormal == 2) {
                                tr += " style='background:#ffff01' ";
                                title += "缺少试剂次数(≤5)  ";
                            } else {
                                tr += " style='background:rgb(254, 154, 154);' ";
                                title += "其他异常  ";
                            }
                        } else {
                            tr += " style='background:white;' ";
                        }
                        if (jsonArrElement[k].absorbanceLow == 1) {
                            title += "吸光度高↑  ";
                        }
                        if (jsonArrElement[k].absorbanceHeight == 1) {
                            title += "吸光度低↓  ";
                        }
                        if (title != "") {
                            tr += "title ='" + title + "'"
                        }
                        markCanBeDelete = 1;
                        if (progress <= 0.5) {
                            progress = "≤0.5";//This inspection reports expression statements which are not assignments or calls. Such statements have no dubious semantics, are normally the result of programmer error.
                        }
                    }
                    fac = 1;
                } else {
                    fac = 0;
                }
                if (fac === 1) {
                    jsonArrElement[k].projectParamId = "";
                    break;
                }
            }
            tr += ">" + progress + "</td>";
            progress = "";
        }
        tr += "<td><select disabled>";
        for (let j = 0; j < 5; j++) {
            //1到5架号
            var a = j + 1;
            var b = jsonArrElement[0].rack;
            if (a == b)
            //相同的架号则选中
                tr += "<option selected>" + (j + 1) + "</option>";
            else
                tr += "<option> " + (j + 1) + "</option>";
        }
        tr += "</select></td><td><select disabled>";
        for (let j = 0; j < 5; j++) {
            //1到5位号
            var a = j + 1;
            var b = jsonArrElement[0].place;
            if (a == b)
            //相同的位号则选中
                tr += "<option selected>" + (j + 1) + "</option>";
            else
                tr += "<option> " + (j + 1) + "</option>";
        }
        if (markCanBeDelete === 1) {
            tr += "</select></td>" +
                "<td style='background-color: #ececec'></td>" +
                "</tr>";
            markCanBeDelete = 0;
            leng++;
        } else {
            tr += "</select></td>" +
                "<td style='color: red'>X</td>" +
                "</tr>";
        }

        // console.log(jsonArrElement);
        // console.log("paramid:" + i);
        $('#tab tr:eq(' + l + ')').after(tr);
        l++;
    }
    console.log("循环次数" + leng);
    maxCode++;
    for(var i = 9;i <leng;i++){
        scrollLength +=  $(" tr")[i].clientHeight;
    }
    // if (leng > 9) {
    //     scrollLength = (leng - 9) * 30;
    // }
    console.log(scrollLength+"scrollLength");
    for (let j = 0; j < 30; j++) {
        var jQtr = $('#tab tr:eq(' + l + ')').next();
        if (jQtr.length === 0) {
            //maxCodeh Checks that jQuery selectors are used in an efficient way. It warns about duplicated selectors which could be cached and optionally about attribute and pseudo-selectors usage.
            tr = "<tr>" +
                "<td>" + (maxCode++) + "</td>" +
                "<td> </td>" +
                "<td>" +
                "<li>&nbsp</li>" +
                "</td>" +
                "<td>" +
                "<li>&nbsp</li>" +
                "</td>" +
                "<td>" +
                "<li>&nbsp</li>" +
                "</td>" +
                "<td>" +
                "<li>&nbsp</li>" +
                "</td>" +
                "<td>" +
                "<li>&nbsp</li>" +
                "</td>" +
                "<td>" +
                "<li>&nbsp</li>" +
                "</td>" +
                "<td>" +
                "<li>&nbsp</li>" +
                "</td>" +
                "<td>" +
                "<li>&nbsp</li>" +
                "</td>" +
                "<td>" +
                "<li>&nbsp</li>" +
                "</td>" +
                "<td><select >" +
                "<option>1</option>" +
                "<option>2</option>" +
                "<option>3</option>" +
                "<option>4</option>" +
                "<option>5</option>" +
                "</select></td>" +
                "<td><select >" +
                "<option>1</option>" +
                "<option>2</option>" +
                "<option>3</option>" +
                "<option>4</option>" +
                "<option>5</option>" +
                "</select></td>" +
                "<td></td>" +
                "</tr>";
            $('#tab tr:eq(' + l + ')').after(tr);
        }
        l++;
    }

    if (quasi <= 2) {
        $("#testAndShow").scrollTop(scrollLength - 90);
    }

    // console.log("这是后台推送的消息：" + event[11]);
}

function circularReading() {
    getProjectListByDataTenToEnd();
    timeout = setTimeout(readDateAndState, 1000);
        setTimeout(function () {
            $("#testAndShow").scrollTop(scrollLength - 90);
        }, 1000);
}


function readDateAndState() {
    getProjectListByDate();
    getEquipmentState();
    getRegentPlace();
    timeout = setTimeout(readDateAndState, 15000);
}

//获得试剂位置
function getRegentPlace() {
    // getProjectListByDate();
    $.ajax({
        type: 'get',
        url: urlhead + '/regentPlace/getRegentPlace',
        async: true,
        data: {},
        jsonp: 'jsoncallback',
        success: function (event) {
            // console.log(event.length);
            // console.log(event[0]);
            // console.log(event);
            regentBottleSet();
            $("#regent tr").each(function (i) {
                if (i > 1 && i < 8) {
                    $(this).find("td").each(function (j) {
                        var innerHTML = $(this)[0].innerHTML;
                        // console.log(i+""+j);
                        var number = (i - 2) * 3 + j;
                        // console.log(event[number].count +"number" +number);
                        var replace = innerHTML.replace("* ", "<span>" + (event[number].project_param_id == "0" ? "" : event[number].name) + " </span>&nbsp&nbsp&nbsp<span style='color: indianred'>" + (event[number].project_param_id == "0" ? "" : event[number].type) + "</span>");
                        replace = replace.replace("   *人份", "<span style='color: #202479'>" + (event[number].project_param_id == "0" ? "&nbsp" : (event[number].count + "人份")) + "</span>");
                        $(this).css("background", "#ffffff");
                        // console.log("剩余数量"+event[number].count+"项目号"+event[number].project_param_id)
                        if (event[number].count >= 20 && event[number].project_param_id > 0) {
                            $(this).css("background", "#92d14f")
                        }
                        if (event[number].count < 20) {
                            $(this).css("background", "#ffff01")
                        }
                        if (event[number].count < 10) {
                            $(this).css("background", "#fe9a9a")
                        }
                        $(this).html(replace);
                    })
                }
            });

            // console.log("这是后台推送的试剂位置：" + event[11]);
            // timeout = setTimeout(getProjectListByDate,2000);//改刷新时间
        },
        error: function () {
            alert("error")
        }
    });
}


/**
 *修改试剂位置
 */
function updateRegentPlace(id, projectParamId, place, type) {
    $.ajax({
        type: 'get',
        url: urlhead + '/regentPlace/updateRegentPlace',
        async: true,
        data: {
            id: id,
            projectParamId: projectParamId,
            place: place,
            type: type
        },
        jsonp: 'jsoncallback',
        success: function (event) {
        },
        error: function () {
            alert("error")
        }
    });
}

/**
 * 初始化方法；加载项目列表
 */
function irLoad(event) {
    $.ajax({
        type: 'get',
        url: urlhead + '/parameter/projectList',
        async: true,
        jsonp: 'jsoncallback',
        success: function (data) {
            quasi++;
            $('#tab').html(
                "<tr class='tab-head' style='height: 40px'>" +
                "                    <td style='position:fixed;top:0px;width: 910px;background-color: white;z-index:2' colspan='14' onclick='getProjectListByDate()'>测试显示&操作区</td>" +
                "                </tr>" +
                "                <tr style='background-color: #f9bf91;font-size: 1px;position:fixed;top:24px;height: 20px;z-index:2;margin-bottom: 20px'>" +
                "                    <td>样本号</td>" +
                "                    <td width='96' style='font-size: 1px'>条码号</td>" +
                "                    <td><select>第一个</select></td>" +
                "                    <td><select></select></td>" +
                "                    <td><select></select></td>" +
                "                    <td><select></select></td>" +
                "                    <td><select></select></td>" +
                "                    <td><select></select></td>" +
                "                    <td><select></select></td>" +
                "                    <td><select></select></td>" +
                "                    <td><select></select></td>" +
                "                    <td>架 号</td>" +
                "                    <td>位 号</td>" +
                "                    <td>操 作</td>" +
                "                </tr>");
            var nameList = data.nameList;
            var namePlaceList = data.namePlaceList;
            var selectStr = "<select title='项目名'>";
            var optionStr = "";
            $.each(nameList, function (i, project) {
                // console.log(project.id);
                var name = project.name;
                if (name == '') {
                    name = project.id;
                }
                optionStr += "<option name=" + name + " value=" + project.id + ">" + name + "</option>";
                selectStr += "<option name=" + name + " value=" + project.id + ">" + name + "</option>";
            });
            optionStr += "<option name='0' value='0'>置空该试剂位</option>";
            selectStr += "</select>";
            $('#tab tr').each(function (i) {
                // 遍历 tr 的各个 td
                $(this).children('td').each(function (j) {
                    var thistd = $(this);
                    if (i === 1 && null != thistd.find("select")[0]) {
                        thistd.html(selectStr);
                        $.each(namePlaceList, function (i, namePlace) {
                            if ((j - 1) === namePlace.id) {
                                thistd.find("option[value='" + namePlace.projectParamId + "']").attr("selected", "selected");
                            }
                        });
                    }
                });
            });
            //设置修改试剂位置时出现的弹窗中的试剂列
            $('#regent_project').html(optionStr);

            $('#tab tr').each(function (i) {
                var trMark = 0;
                // 遍历 tr 的各个 td
                $(this).children('td').each(function (j) {
                    var tdMark = 0;
                    if (i >= 1) {
                        // console.log($(this).find("select")[0]);
                        var findSelect = $(this).find("select")[0];
                        if (null != findSelect) {
                            //把项目名称放入列表
                            projectNameList[j] = findSelect.value;
                        }
                    }
                    if (tdMark === 1) {
                        trMark = 1;
                    }
                });
                if (trMark === 1) {
                    code++;
                }
            });

            dealProject(event);
        },
        error: function () {
            $('#projectname').html("请联系管理员");
        }
    });
}

/**
 * 保存项目
 */
function saveProject(projectParamid, placeNo, rackNo, code) {
    $.ajax({
        type: 'get',
        url: urlhead + '/productTest/saveProject',
        async: true,
        data: {
            projectParamId: projectParamid,
            humanCode: code,
            placeNo: placeNo,
            rackNo: rackNo,
            type: $("#tobeQC").is(':checked') ? 3 : 1,
        },
        jsonp: 'jsoncallback',
        success: function () {
            console.log("保存成功");

        },
        error: function () {
            $('#projectname').html("请联系管理员");
        }
    });
}

/**
 * 保存项目列表
 */
function saveProjectList(projectList) {
    $.ajax({
        type: 'get',
        url: urlhead + '/productTest/saveProjectList',
        async: true,
        data: {
            projectListStr: JSON.stringify(projectList),
        },
        jsonp: 'jsoncallback',
        success: function (event) {
            console.log("保存成功");
            if (event == -2) {
                alert("请检查试剂位置是否选择!");
            }
        },
        error: function () {
            $('#projectname').html("请联系管理员");
        }
    });
}


/**
 * 获取仪器状态数据
 */
function getEquipmentState() {
    $.ajax({
        type: 'get',
        url: urlhead + '/equipmentState/selectOne?id=1',
        async: true,
        jsonp: 'jsoncallback',
        success: function (data) {
            $("#rackNo").html(data.rackNo + "号架");
            $("#placeNo").html(data.placeNo + "号位");
            var $pureWater = $("#pureWater");
            var pureWater = data.pureWater;
            if (pureWater === 1) {
                $pureWater.html("<img src='../../images/inputAndResult/greenBucket.png' height='90' width='75'>")
            } else {
                $pureWater.html("<img src='../../images/inputAndResult/redBucket.png' height='90' width='75'>")
            }
            var wasteWater = data.wasteWater;
            var $wasteWater = $("#wasteWater");
            if (wasteWater === 1) {
                $wasteWater.html("<img src='../../images/inputAndResult/greenBucket.png' height='90' width='75'>")
            } else {
                $wasteWater.html("<img src='../../images/inputAndResult/redBucket.png' height='90' width='75'>")
            }
        },
        error: function () {
            $('#projectname').html("请联系管理员");
        }
    })
}

/**
 *查下一个用户code，并且保存 手动
 */
$(document).ready(function () {
    $('#save').click(function () {
        $.ajax({
            type: 'get',
            url: urlhead + '/productTest/selectNextHumanCode',
            async: true,
            jsonp: 'jsoncallback',
            success: function (data) {
                if (savetime == 0) {
                    savetime = 1;
                } else {
                    return;
                }
                code = data;
                command = data;
                // console.log("下一个是" + data);
                saveList();

                // $('#projectname').html("保存成功");
                // if (quaslength > 0) {
                //     sendList();
                // }
            },
            error: function () {
                // $('#projectname').html("请联系管理员");
            }
        });
    });
});


//保存手动测试项目
function saveList() {
    var projectList = [];
    // 遍历 tr
    var turn = 1;
    $('#tab tr').each(function (i) {
        var trMark = 0;
        // 遍历 tr 的各个 td
        $(this).children('td').each(function (j) {
            var project = {};
            var tdMark = 0;
            if (i === 1) {
                console.log("i");
                var findSelect = $(this).find("select")[0];
                if (null != findSelect) {
                    projectNameList[j] = findSelect.value;
                    // console.log(projectNameList);
                }
            } else {
                var findLi = $(this).find("li")[0];
                if (null != findLi && "liChance" === findLi.className) {
                    //
                    tdMark = 1;
                    var rackId = $('#tab tr:eq(' + i + ') td:nth-child(12)').find("select")[0].value;
                    var placeId = $('#tab tr:eq(' + i + ') td:nth-child(13)').find("select")[0].value;
                    var projectParamId = projectNameList[j];
                    var humanCode = $('#tab tr:eq(' + i + ') td:nth-child(1)')[0].innerText;
                    project.projectParamId = projectParamId;
                    project.placeId = placeId;
                    project.rackId = rackId;
                    project.humanCode = humanCode;
                    projectList.push(project);
                    // saveProject(projectParamId, placeId, rackId,humanCode);
                    // console.log(humanCode);
                    turn++;
                }
            }
            if (tdMark === 1) {
                trMark = 1;
            }
        });
        if (trMark === 1) {
            code++;
        }

    });
    // console.log(projectList);
    saveProjectList(projectList);
    setTimeout(getProjectListByDate, 500);
    setTimeout(refush, 500);
}


//保存自动测试项目
function saveAutoList() {
    var projectList = $("#projectname input").not(".layui-btn-primary");

    // console.log(projectList.length);
    $.each(projectList, function (i, project) {
        for (var j = 1; j < 6; j++) {
            saveProject(project.id, null, null);
        }
        alert("保存成功,project.id" + project.value);
    });
    getProjectListByDate();
}


//发送自动检测项目
function sendAutoList() {
    // console.log(projectList.length);
    send(-1, code, 5);
}

//发送手动检测项目
function sendList() {
    // console.log(projectList.length);
    send(-2, code, 5);
}


/**
 * 初始化试剂位置显示区
 */
function regentBottleSet() {
    var num = 1;
    $('#regent tr').each(function (i) {
        var trMark = 0;
        // 遍历 tr 的各个 td
        $(this).children('td').each(function (j) {
            if (i >= 2 && i < 8) {
                var tdstr = num + "<br> * <br>   *人份";
                tdstr.replace(num, "a");
                $(this).html(tdstr);
                $(this).attr("style", "font-size: 16px");
                num++;
            }
        });
    });
}

/**
 * 获取仪器状态数据
 */
function deleteProjects() {
    $.ajax({
        type: 'get',
        url: urlhead + '/productTest/deleteProjects',
        async: true,
        jsonp: 'jsoncallback',
        success: function (data) {
            refush();
        },
        error: function () {
            $('#projectname').html("请联系管理员");
        }
    })
}

$(document).ready(function () {
    $('#dealButton img').on('click', function () {
        deleteProjects();
    });
    $('html').mousedown(function () {
        //鼠标按下
        key = 1;
    }).mouseup(function () {
        //鼠标松开
        key = 0;
    });
    $('#tab').on('mousedown', 'li', function () {
        //鼠标按下
        key = 1;
        if ($(this).hasClass("liChance")) {
            $(this).removeClass("liChance");
            return;
        }
        $(this).attr("class", "liChance");
    }).on('mouseup', 'li', function () {
        //鼠标松开
        key = 0;
    }).on('mouseenter', 'li', function () {
        //鼠标进入
        if (key === 1) {
            if ($(this).hasClass("liChance")) {
                $(this).removeClass("liChance");
                return;
            }
            $(this).attr("class", "liChance");
        }
    });

    $("#getProjectListByDate").click(function () {
        alert(new Date().getFullYear() + "-" + (new Date().getMonth() + 1) + "-" + new Date().getDate());
        getProjectListByDate();
    });

    $(".do-icon-start").click(function () {
        console.log("start");
        sendList();
        // setTimeout(refush,500);
        // circularReading();//改刷新时间
    });

    $(".do-icon-stop").click(function () {
        console.log("stop");
        clearTimeout(timeout);
    });

    $(".do-icon-shutdown").click(function () {
        console.log("shutdown");
        clearTimeout(timeout);
    });
    var deleteHumanCode;
    var deltd;
    var deltr;
    var deltab;
    var deltd1;
    $("#tab ").on('click', 'td:nth-child(1)', function () {
        // 第一列单击修改样本号事件
        var td = $(this);
        console.log(td[0].innerHTML);
        if (0 < td.find("input").length) {
            var inputText = td.find("input")[0].innerText;
            if (inputText > 0) {
                $(this).html(inputText);
            }
            return;
        }
        if ('测试显示&amp;操作区' === td[0].innerHTML) return;
        var input = '<input my= ' + $(this)[0].innerText + ' type="number" style="width: 42px;border: none;padding: 0;height: 18px;">';
        td.html(input);
        td.find("input")[0].focus();
    }).on('blur ', 'input', function () {
        //blur 失去焦点
        var message = $(this)[0].value;
        if ($(this)[0].value === "") {
            message = $(this).attr("my");
        }
        var fp = $(this).parent();
        fp.html(message);
        // $(this).attr("my")
        console.log(fp);
        //将接下来的第一列都修改
        var sp = fp.parent();
        var nextAll = sp.nextAll();
        nextAll.each(function (i) {
            var td = $(this).find("td:nth-child(1)");
            console.log(td.innerHTML);
            td.html((i + 1 + parseInt(message)));
        });
        console.log(nextAll);
    }).on('click', 'td:nth-child(14)', function () {
        ///删除
        deltd = $(this);
        // console.log(deltd1);
        // console.log(deltr);
        deleteHumanCode = deltd.parent().children()[0].innerHTML;
        if ("X" == deltd[0].innerHTML) {
            var deleteProjectBox = $("#deleteProjectBox");
            // noinspection JSAnnotator
            // if (deltr ==null || deltr.parentNode == null || deltr[0] == "td"){
            // }else {
            deleteProjectBox.find("#delProjectSure").html("确认删除项目" + deleteHumanCode + '吗？');
            deleteProjectBox.fadeIn("slow");
            // }
        }
    });
    //删除项目
    $("#delProject").on('click', function () {
        var $tab = $("#tab td:nth-child(1)");
        $tab.each(function (i) {
            if ($tab[i].innerText == deleteHumanCode) {
                deltd1 = $tab[i];
            }
        });
        // console.log($tab.html());
        // console.log(deltd1.parentNode);
        // console.log(deltd1);
        deltd1.parentNode.parentNode.removeChild(deltd1.parentNode);

        $.ajax({
            type: 'GET',
            url: urlhead + '/patient/deleteByHumanCode',
            async: true,
            data: {
                humanCode: deleteHumanCode
            },
            jsonp: 'jsoncallback',
            success: function (event) {
                if (deltr != null && deltr.parentNode != null) {
                    deltr.parentNode.removeChild(deltr);
                }
                refush();
                $("#deleteProjectBox").fadeOut("fast");
            },
            error: function () {
                alert("error")
            }
        });
        deltr = null;
    });

    $(".regent-bottle td").on('click', function () {
        var loginBox = $("#LoginBox");
        loginBox.find("#updateBox").html("确认修改试剂位置" + $(this).attr("place"));
        loginBox.find("#updateBox").attr("place", $(this).attr("place"));
        loginBox.fadeIn("slow");
    });
    //关闭悬浮的窗口
    $(".close_btn").hover(function () {
        $(this).css({color: 'black'})
    }, function () {
        $(this).css({color: '#999'})
    }).on('click', function () {
        $("#LoginBox").fadeOut("fast");
        $("#deleteProjectBox").fadeOut("fast");
        $("#mask").css({display: 'none'});
    });
    //修改    试剂位置
    $("#updateBox").on("click", function () {
        var parent = $(this).parent().parent();
        var regent_project = parent.find("#regent_project");
        var type = parent.find("#regent_type")[0].value;
        var id = regent_project[0].value;
        console.log(id);
        var place = $(this).attr("place");
        updateRegentPlace(place, id, place, type);
        setTimeout(refush, 500);
    });

    /**
     * 初始化
     */
    $("#init").on('click', function () {
        $.ajax({
            type: 'GET',
            url: urlhead + '/adjusted/init',
            async: true,
            jsonp: 'jsoncallback',
            success: function (event) {
            },
            error: function () {
                alert("error");
            }
        });
    });


});

function refush() {
    location = location;

}


