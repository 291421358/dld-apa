package com.laola.apa.controller;


import com.laola.apa.entity.ProjectNamePlace;
import com.laola.apa.entity.ProjectParam;
import com.laola.apa.server.ParamIntf;
import com.laola.apa.server.ProjectNamePlaceServer;
import com.laola.apa.utils.QRCodeUtils;
import com.laola.apa.vo.ProjectListVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "parameter")
public class ParameterController {
    @Autowired
    private ParamIntf paramIntf;
    @Autowired
    private ProjectNamePlaceServer projectNamePlaceServer;




    /**
     * 项目列表
     * @return
     */
    @RequestMapping(value = "projectList" , method = RequestMethod.GET)
    public Map<String, Object> projectList(){
        List<ProjectListVO> projectListVOS = paramIntf.projectList();
        List<ProjectNamePlace> namePlaceList = projectNamePlaceServer.queryAll(null);
        Map<String,Object> projectListMap = new HashMap<>();
        projectListMap.put("nameList",projectListVOS);
        projectListMap.put("namePlaceList",namePlaceList);
        return projectListMap;
    }

    /**
     * 单个项目查询
     * @param id
     * @return
     */
    @RequestMapping(value = "oneProject" , method = RequestMethod.GET)
    public ProjectParam onePoject(Integer id){
        ProjectParam projectParam = paramIntf.onePoject(id);
        return projectParam;
    }

    /**
     * 更新
     * @param projectParam
     * @return
     * @deprecated updateByPrimaryKeySelective 方法 ，传入的值为空则不修改
     */
    @RequestMapping(value = "update" , method = RequestMethod.GET)
    public String update(ProjectParam projectParam){
        System.out.println(projectParam.getId());

        paramIntf.update(projectParam);
        return "200";
    }

    /**
     * 生成二维码
     * @param projectParam
     * @return
     * @deprecated updateByPrimaryKeySelective 方法 ，传入的值为空则不修改
     */
    @RequestMapping(value = "createQRCode" , method = RequestMethod.GET)
    public String createQRCode(ProjectParam projectParam){
        System.out.println(projectParam.getId());

        paramIntf.createQRCode(projectParam.getId());
        return "200";
    }

}
