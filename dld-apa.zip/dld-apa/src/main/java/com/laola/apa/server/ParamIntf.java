package com.laola.apa.server;

import com.laola.apa.entity.ProjectParam;
import com.laola.apa.vo.ProjectListVO;

import java.util.List;

public interface ParamIntf {
    //查询列表
    List<ProjectListVO> projectList();
    //根据id查单条数据
    ProjectParam onePoject(int id);
    //修改
    boolean update(ProjectParam projectParam);
    //生成二维码
    String createQRCode(int id);
}
