package com.laola.apa.server;

import com.laola.apa.entity.RegentPlace;

import java.util.List;
import java.util.Map;

public interface ReagentPlaceIntf {
    List<Map<String, Object>> getRegentPlace();
    //修改试剂位置
    int updateRegentPlace(RegentPlace regentPlace);
    //试剂份数减一份
    int minusOneCopyReagent(int projectId);
    //获取试剂数
    Integer getCopies(int projectId);

    boolean getParamIds(int[] paramIds);
}
