package com.laola.apa.entity;

import javax.persistence.*;

@Table(name = "laola.regent_place")
public class RegentPlace {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 项目参数id
     */
    @Column(name = "project_param_id")
    private Integer projectParamId;

    /**
     * 试剂位置
     */
    @Column(name = "place")
    private Integer place;

    /**
     * 试剂类型
     */
    @Column(name = "type")
    private String type;

    @Column(name = "count")
    private Integer count;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getProjectParamId() {
        return projectParamId;
    }

    public void setProjectParamId(Integer projectParamId) {
        this.projectParamId = projectParamId;
    }

    public Integer getPlace() {
        return place;
    }

    public void setPlace(Integer place) {
        this.place = place;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return "RegentPlace{" +
                "id=" + id +
                ", projectParamId=" + projectParamId +
                ", place=" + place +
                ", type='" + type + '\'' +
                ", count=" + count +
                '}';
    }
}
