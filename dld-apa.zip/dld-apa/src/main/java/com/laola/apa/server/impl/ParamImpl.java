package com.laola.apa.server.impl;

import com.laola.apa.entity.Project;
import com.laola.apa.entity.ProjectParam;
import com.laola.apa.entity.Scaling;
import com.laola.apa.mapper.ProjectMapper;
import com.laola.apa.mapper.ProjectParamMapper;
import com.laola.apa.mapper.ScalingMapper;
import com.laola.apa.server.ParamIntf;
import com.laola.apa.utils.DataUtil;
import com.laola.apa.utils.DateUtils;
import com.laola.apa.utils.QRCodeUtils;
import com.laola.apa.vo.ProjectListVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

import java.util.*;

@Service
public class ParamImpl implements ParamIntf {

    @Autowired
    private ProjectParamMapper projectParamMapper;
    @Autowired
    private ProjectMapper projectMapper;

    @Autowired
    private ScalingMapper scalingMapper;
    /**
     * 查询所有项目的id和项目名
     * @return List<ProjectListVO>
     */
    @Override
    public List<ProjectListVO> projectList() {
        List<ProjectParam> projectParamList = projectParamMapper.selectAll();
        List<ProjectListVO> projectList = new ArrayList<>();
        for (ProjectParam projectParam : projectParamList) {
            ProjectListVO projectListVO = new ProjectListVO();
            projectListVO.setId(projectParam.getId());
            projectListVO.setName(projectParam.getName());
            projectList.add(projectListVO);
        }
        return projectList;
    }

    /**
     * 根据项目id查询项目详情
     * @param id
     * @return ProjectParam
     */
    @Override
    public ProjectParam onePoject(int id) {
        ProjectParam projectParam = new ProjectParam();
        projectParam.setId(id);
        projectParam = projectParamMapper.selectOne(projectParam);
        //浮点数退位
        carryDigit(projectParam,"P");
        return projectParam;
    }

    /**
     * 修改项目参数
     * @param projectParam
     * @return
     */
    @Override
    public boolean update(ProjectParam projectParam) {
        ProjectParam projectParam1 = projectParamMapper.selectByPrimaryKey(projectParam);
        if (!Objects.equals(projectParam.getName(), projectParam1.getName())){
            projectMapper.deleteProjectByParamId(projectParam.getId());
        }

        carryDigit(projectParam,"M");
        projectParamMapper.updateByPrimaryKeySelective(projectParam);

        return true;
    }

    /**
     * 生成二维码
     * @param id
     * @return
     *
     *         String text = "{'param':[{'pn':'ARU总蛋白','me':'2','sas':'5','sat':'2','ftd':'300','std':'0','mw':'4','aw':'7','u':'2','mia':'1'
     *         ,'maa':'3','spm':'1','epm':'18','spa':'0','epa':'0','nh':'40','nl':'0'}]}";  //这里设置自定义网站url
     */
    @Override
    public String createQRCode(int id) {
        ProjectParam p = new ProjectParam();

        p.setId(id);
        p = projectParamMapper.selectOne(p);
        carryDigit(p,"P");
        Map<String,List<Map<String,String>>> map = new HashMap<>();
        List<Map<String,String>> list = new ArrayList<>();
        Map<String,String> paramMap = new HashMap<>();
        paramMap.put("","");
        String me = p.getComputeMethod();
        switch (me){
            case  "两点法":
                me="1";
                break;
            case  "速率法":
                me="2";
                break;
            case "终点法":
                me="3";
        }
        String sat = p.getSampleType();
        switch (sat){
            case  "血清":
                sat="1";
                break;
            case  "全血":
                sat="2";
                break;
            case "尿样":
                sat="3";
        }
        String dd = p.getDecimalDigit();
        switch (dd){
            case  "0位":
                dd="0";
                break;
            case  "1位":
                dd="1";
                break;
            case "2位":
                dd="2";
        }
        String u = p.getMeterageUnit();
        StringBuilder text = new StringBuilder("{z:[{a:'" + p.getChineseName() + "',b:'" + p.getName() + "',c:'" + me + "',d:'" + p.getSampleSize() + "',e:'" + sat + "',f:'" + p.getReagentQuantityNo1() + "',g:'"
                + p.getReagentQuantityNo2() + "',h:'" + p.getMainWavelength() + "',i:'" + p.getAuxiliaryWavelength() + "',j:'" + u + "',k:'"
                + p.getMinAbsorbance() + "',l:'" + p.getMaxAbsorbance() + "',m:'" + p.getMainIndicationBegin() + "',n:'" + p.getMainIndicationEnd() + "',o:'"
                + p.getAuxiliaryIndicationBegin() + "',p:'" + p.getAuxiliaryIndicationEnd() + "',q:'" + p.getNormalHigh() + "',r:'" + p.getNormalLow() + "',s:'" + dd + "'}],t:[");
        text = new StringBuilder(DateUtils.unicodeEncodeOnlyCN(text.toString()));

        Example example = new Example(Project.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("projectParamId", id);
        criteria.andEqualTo("type", 2);
        String preDate = DataUtil.getPreDateByUnit(p.getFactor(), 1, 12);
//                    logger.info("factor:"+factor);
        criteria.andBetween("starttime", p.getFactor(), preDate);
        List<Project> projects = projectMapper.selectByExample(example);

        for (Project project : projects) {
            text.append(project.getDensity()).append(",").append(project.getAbsorbance()).append(",");
        }


        Scaling scaling = scalingMapper.queryById(p.getFactor());
        String algorithm = scaling.getAlgorithm();
        text.deleteCharAt(text.lastIndexOf(","));

        switch (algorithm){
            case  "三次样条函数":
                algorithm="1";
                break;
            case  "一次曲线":
                algorithm="2";
                break;
            case "二次曲线拟合":
                algorithm="3";
                break;
            case "RodBard":
                algorithm="4";
        }
        text.append("],u:'").append(algorithm).append("'}");

        String logoPath = "C:\\img\\test.jpg";
        String destPath = "C:\\img\\";
        String encode = null;
        try {
            encode = QRCodeUtils.encode(text.toString(), logoPath, destPath, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(encode);

        Process process = null;//Process代表一个进程对象
        QRCodeUtils.openQRCode(encode, process);
        return null;
    }

    private ProjectParam carryDigit(ProjectParam projectParam, String PorM){
        String minAbsorbance = projectParam.getMinAbsorbance();
        String maxAbsorbance = projectParam.getMaxAbsorbance();
        String normalLow = projectParam.getNormalLow();
        String normalHigh = projectParam.getNormalHigh();
        Float abs = 0F;
        Float nor = 0F;
        if (PorM.equals("P")){
            abs = 10F;
            nor= 100F;
        }
        if (PorM.equals("M")){
            abs = 0.1F;
            nor= 0.01F;
        }
        projectParam.setMinAbsorbance(DateUtils.carryDigit(minAbsorbance,abs));
        projectParam.setMaxAbsorbance(DateUtils.carryDigit(maxAbsorbance,abs));
        projectParam.setNormalLow(DateUtils.carryDigit(normalLow,nor));
        projectParam.setNormalHigh(DateUtils.carryDigit(normalHigh,nor));
        return projectParam;
    }
}
