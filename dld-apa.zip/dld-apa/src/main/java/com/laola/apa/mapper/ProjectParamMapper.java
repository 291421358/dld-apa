package com.laola.apa.mapper;

import com.laola.apa.entity.ProjectParam;
import com.laola.apa.utils.MyMapper;
import org.springframework.stereotype.Service;

@Service
public interface ProjectParamMapper extends MyMapper<ProjectParam> {
}